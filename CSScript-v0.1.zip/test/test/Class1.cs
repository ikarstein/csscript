﻿using System;
using System.Collections.Generic;

using System.Text;

namespace test
{
    class Class1
    {
        public Class1() { }

        public string TestString()
        {
            return "This is a test for CSScript";
        }

        public char[] TestCharArray()
        {
            return new char[] { 'H', 'e', 'l', 'l', 'o' };
        }

        public float TestFloat() {
            return 0.9F;
        }
    }
}
